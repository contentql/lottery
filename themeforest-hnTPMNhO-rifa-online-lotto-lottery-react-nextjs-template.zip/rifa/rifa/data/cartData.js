const cartData = [
  {
    id: 1,
    ticket: [1, 24, 50, 2, 3, 4, 9],
  },
  {
    id: 2,
    ticket: [1, 24, 50, 2, 3, 4, 9],
  },
  {
    id: 3,
    ticket: [1, 24, 50, 2, 3, 4, 9],
  },
  {
    id: 4,
    ticket: [1, 24, 50, 2, 3, 4, 9],
  },
  {
    id: 5,
    ticket: [1, 24, 50, 2, 3, 4, 9],
  },
  {
    id: 6,
    ticket: [1, 24, 50, 2, 3, 4, 9],
  },
  {
    id: 7,
    ticket: [1, 24, 50, 2, 3, 4, 9],
  },
  {
    id: 8,
    ticket: [1, 24, 50, 2, 3, 4, 9],
  },
];

export default cartData;
