const faqData = [
  {
    id: 1,
    question: "You Have Questions",
    answer:
      "Do not hesitate to send us an email if you can't find what you're looking for.",
  },
  {
    id: 2,
    question: "Can I cancel my ticket?",
    answer: `Lorem ipsum dolor, sit amet consectetur adipisicing elit. Rerum dignissimos consectetur aspernatur expedita aut reiciendis magni tempore ullam libero, voluptate nam accusamus est a
        debitis, obcaecati beatae possimu distinctio?`,
  },
  {
    id: 3,
    question: " Can I enter promotions if I buy my tickets using Rifa lottery?",
    answer: `Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
        labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo viverra
        maecenas accumsan lacus vel facilisis.`,
  },
  {
    id: 4,
    question: "What are the different ticket types?",
    answer: `Lorem ipsum dolor, sit amet consectetur adipisicing elit. Rerum dignissimos consectetur
        aspernatur expedita aut reiciendis magni tempore ullam libero, voluptate nam accusamus est a
        debitis, obcaecati beatae possimus veniam distinctio?`,
  },
  {
    id: 5,
    question: "What are the draw close off times?",
    answer: `Lorem ipsum dolor, sit amet consectetur adipisicing elit. Rerum dignissimos consectetur
        aspernatur expedita aut reiciendis magni tempore ullam libero, voluptate nam accusamus est a
        debitis, obcaecati beatae possimus veniam distinctio?`,
  },
];

export default faqData;
