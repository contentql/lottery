import winner_1 from "/public/images/winner/1.png";
import winner_2 from "/public/images/winner/2.png";

const testimonialData = [
  {
    id: 1,
    img: winner_2,
    name: "Dave Ford",
    comment: `“Unbelievable this is a dream come true,no way would I
      ever think I would own a car like this”`,
  },
  {
    id: 2,
    img: winner_1,
    name: "Cristina",
    comment: `“Unbelievable this is a dream come true,no way would I
      ever think I would own a car like this”`,
  },
];

export default testimonialData;
